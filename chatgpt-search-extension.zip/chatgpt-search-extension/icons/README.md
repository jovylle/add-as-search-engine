# Icon Placeholders

This folder should contain the extension icons in the following sizes:
- icon16.png (16x16 pixels)
- icon32.png (32x32 pixels)  
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

You can create simple icons or download ChatGPT-related icons to replace these placeholders.

For now, the extension will work without custom icons (Chrome will use default ones).